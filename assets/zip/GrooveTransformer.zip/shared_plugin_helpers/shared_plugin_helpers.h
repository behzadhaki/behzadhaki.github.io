#pragma once

#if 0

BEGIN_JUCE_MODULE_DECLARATION

      ID:               shared_plugin_helpers
      vendor:           Eyal Amir
      version:          0.0.1
      name:             shared_plugin_helpers
      description:      Shared plugin helpers
      license:          GPL/Commercial
      dependencies:     juce_audio_utils

     END_JUCE_MODULE_DECLARATION

#endif

#include "ProcessorBase/Helpers.h"
#include "ProcessorBase/ProcessorBase.h"